package com.example.democlient

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DemoclientApplication

fun main(args: Array<String>) {
	runApplication<DemoclientApplication>(*args)
}

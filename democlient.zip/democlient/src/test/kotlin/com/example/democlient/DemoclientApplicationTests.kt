package com.example.democlient

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoclientApplicationTests {

	@Test
	fun contextLoads() {
	}

}
